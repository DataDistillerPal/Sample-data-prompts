# PII Register

Every column containing personal or sensitive data, across all models. Agents must not query these columns'
values without `APPROVE PII` (see `.github/instructions/data-policy.instructions.md`).

Status: **Confirmed** (you verified) · **Suggested** (flagged by name pattern, awaiting your review) · **Not PII** (reviewed, safe)

| Model | Table | Column | Category | Sensitive? | Hidden in model? | OLS? | Status |
|---|---|---|---|---|---|---|---|
| _Example Sales Model_ | _Dim Customer_ | _Email_ | Contact | No | Yes | No | Suggested |
| _Example Sales Model_ | _Dim Employee_ | _Salary_ | Compensation | **Yes** | Yes | Yes | Confirmed |

Categories: Name · Contact (email/phone/address) · Identifier (ID numbers, account numbers) · Demographic (DOB, gender…) ·
Compensation · Health · Free text · Other
