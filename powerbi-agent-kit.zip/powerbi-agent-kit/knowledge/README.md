# Knowledge Base: how the agents "know" your models

You don't train the model. You give it **context**. Copilot reads these files at the start of each task, so the
better they are, the better the agents get. Think of this folder as the agent's long-term memory.

**Rule: metadata only.** No data values, no samples, no PII, no credentials. Ever.

| File | What it holds | Who maintains it |
|---|---|---|
| `model-catalog.md` | Index of every semantic model: where it lives, owner, purpose | catalog-builder agent (+ you) |
| `models/<model>.md` | One file per model: tables, relationships, key measures, date table, sources, PII columns | catalog-builder agent |
| `standards/date-table.md` | Your standard date table: name, columns, fiscal year, how it's shared | **You** (fill in once) |
| `pii-register.md` | Every PII / sensitive column across models | catalog-builder suggests, **you** confirm |
| `learned-rules.md` | Corrections you've taught the agent | Agents propose, **you** approve |
| `glossary.md` | Business terms and KPI definitions (what "Net Sales" means at each client) | **You** |

## How to build it (in order)
1. Fill in `standards/date-table.md` (10 minutes, and it saves hours).
2. Fill in `glossary.md` with your top 10 KPIs.
3. For each model: run `/onboard-model` → approve → repeat. Start with your 3 most-used models.
4. Confirm the suggested PII columns in `pii-register.md`.
5. Re-run `/onboard-model` on a model after big changes (it shows only what changed).

## Even better: keep the models themselves in this repo
Save each model as a **PBIP** project under `models/` and commit to Git. The semantic model is then stored as
readable **TMDL** text files, so agents can read every table, column, measure and relationship directly, and you get
version history and an undo button for every agent change.

```
models/
├── SalesModel/        ← SalesModel.pbip + .SemanticModel/ + .Report/
└── FinanceModel/
```

## Tenant-wide inventory (optional, needs a Fabric admin)
If you need a list of *every* model in the organisation, a Fabric/Power BI admin can export it with the admin
scanner (metadata scanning) APIs. Paste the list (names, workspaces, owners only) into `model-catalog.md` and
onboard the important ones.
