# Standard Date Table  *(fill this in. Agents rely on it.)*

Most of my semantic models already contain this date table. **Agents must reference it and must never create
a calendar/date table** (no `CALENDAR()`, `CALENDARAUTO()`, Power Query date lists, or SQL date generators).
If a model doesn't have it, ask me.

## Identity
- **Table name in models:** `[Date]`   ← e.g. `Date`, `Dim Date`, `Calendar`
- **Date column (key for time intelligence):** `[Date][Date]`
- **Marked as date table:** `[Yes / No]`
- **Calendars defined (calendar-based time intelligence):** `[No / Yes — calendar names: …]`
- **Source:** `[shared dataflow / warehouse view rpt.vw_DimDate / Power Query in each model]`
- **Date range:** `[2015-01-01 to 2030-12-31]` (extends automatically? `[yes/no]`)

## Relationships
- Joins to facts on: `[Date][Date]` → `Fact[Order Date]`  *(or `DateKey` integer yyyymmdd: say which)*
- Role-playing dates (ship, due, invoice): `[inactive relationships + USERELATIONSHIP]`

## Fiscal year
- Fiscal year starts: `[July 1]` (year-end argument for TOTALYTD: `["6/30"]`)
- Fiscal year label convention: `[FY2027 = Jul 2026 – Jun 2027]`

## Columns available (agents: use these, don't recreate them)
| Column | Example | Notes |
|---|---|---|
| `Date` | 2026-11-21 | Key |
| `Year` | 2026 | |
| `Quarter` | Q4 | |
| `Month Name` | November | Sort by `Month Number` |
| `Month Number` | 11 | |
| `Year Month` | 2026-11 | |
| `Week of Year` | 47 | `[ISO / US]` |
| `Day of Week` | Saturday | |
| `Is Weekend` | TRUE | |
| `Fiscal Year` | FY2027 | |
| `Fiscal Quarter` | FQ2 | |
| `Fiscal Month Number` | 5 | |
| `Is Current Month` | TRUE | `[if exists]` |
| `Is Working Day` | FALSE | `[if exists]` |
| `[add yours]` | | |

## Exceptions
Models that do **not** use the standard date table: `[list, or "none"]`
