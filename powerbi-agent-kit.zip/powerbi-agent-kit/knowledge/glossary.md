# Business Glossary & KPI Definitions

Agents use this to avoid guessing what business terms mean. If a client defines a KPI differently, add a client column or a separate section.

| Term / KPI | Definition | Includes | Excludes | DAX measure (if exists) | Owner |
|---|---|---|---|---|---|
| _Net Sales_ | _Gross sales minus returns and discounts_ | _Shipped orders_ | _Tax, cancelled orders_ | `[Net Sales]` | _Finance_ |
| | | | | | |
