# Semantic Model Catalog

Index of all semantic models the agents should know about. Metadata only.
Maintained by the **catalog-builder** agent (`/onboard-model`) and by you.

| Model | Location (Desktop / Workspace / PBIP path) | Env | Owner | Client / Area | Purpose | Standard date table? | Knowledge file | Last catalogued |
|---|---|---|---|---|---|---|---|---|
| _Example Sales Model_ | _Fabric: Finance-Dev_ | dev | _Johan_ | _Contoso_ | _Sales & margin reporting_ | Yes | `models/example-sales-model.md` | _yyyy-mm-dd_ |
