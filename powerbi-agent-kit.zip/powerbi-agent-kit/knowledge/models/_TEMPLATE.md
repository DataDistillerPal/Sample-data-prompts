# Model: <Model Name>

> Metadata only, no data values or PII. Last catalogued: <yyyy-mm-dd> by catalog-builder

## Overview
- **Location:** <Power BI Desktop file / Fabric workspace + model / PBIP path>
- **Environment:** <dev / test / prod>
- **Owner:** <name>  · **Client / area:** <…>
- **Business purpose:** <confirmed by user>
- **Storage mode:** <Import / DirectQuery / Direct Lake / Composite>
- **Compatibility level:** <…>
- **Refresh:** <schedule, incremental refresh yes/no>

## Date table
- Uses standard date table: <Yes / No>. Table: `<name>`, marked: <yes/no>
- Differences from `knowledge/standards/date-table.md`: <none / list>

## Tables
| Table | Type | Rows (approx) | Grain / notes |
|---|---|---|---|
| | Fact / Dim / Date / Measures | | |

## Relationships
| From (many) | To (one) | Active | Direction | Notes |
|---|---|---|---|---|

## Key measures
| Measure | Folder | Description |
|---|---|---|

## Sources (no credentials)
| Query / table | Source type | Server / DB / file | Folds? |
|---|---|---|---|

## Security
- RLS roles: <names>
- OLS: <yes/no>
- PII columns (see `pii-register.md`): <Table[Column], …>

## Known issues / notes
- <…>
