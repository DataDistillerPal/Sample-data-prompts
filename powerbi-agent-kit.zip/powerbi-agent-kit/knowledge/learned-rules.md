# Learned Rules

Corrections and preferences the user has taught the agents. Agents read this every session.
Agents may **propose** additions; they're only written after the user approves. No data values or PII.

Format: `- [yyyy-mm-dd] [area] Rule. (Why / context)`

## DAX
- [2026-11-21] [DAX] Minimise CALCULATE: use the no-CALCULATE ladder in `dax-best-practices` first. (User preference)
- [2026-11-21] [DAX] Never create a date table; reference the standard date table. (Most models already have one)

## Power Query

## SQL

## Python

## Modelling

## Communication
- [2026-11-21] [General] Ask before assuming; list assumptions explicitly when told to proceed. (User preference)
