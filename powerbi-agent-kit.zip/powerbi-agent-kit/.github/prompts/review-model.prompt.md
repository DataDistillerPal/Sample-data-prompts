---
agent: model-reviewer
description: 'Full best-practice and privacy review of a semantic model'
argument-hint: 'Model name and where it is'
---

Connect to: ${input:model:e.g. 'Contoso Sales' in Power BI Desktop}

Run a full review following your workflow. Focus on: ${input:focus:performance, DAX, relationships, privacy, or "everything"}

Finish with the findings table, health score and next steps.
