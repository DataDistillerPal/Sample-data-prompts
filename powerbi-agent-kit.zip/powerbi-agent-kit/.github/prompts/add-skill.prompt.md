---
agent: analytics-engineer
description: 'Create a new skill in .github/skills from a description or a correction you keep repeating'
argument-hint: 'What should the skill teach? e.g. "our currency conversion measure pattern"'
---

Create a new agent skill for: ${input:topic:What should this skill cover?}

Steps:
1. Read `.github/skills/README.md` (template and tips) and list existing skills so you don't duplicate one.
   If an existing skill should be extended instead, say so and propose the edit.
2. Ask me up to 5 questions to capture the standard: rules, a good example, a bad example, how to validate.
3. Draft `.github/skills/<skill-name>/SKILL.md` following the template. Make the `description` specific, with trigger words.
4. Show me the full draft. **Do not write any file until I approve.**
5. After approval: create the file and add a row to the "Current skills" table in `.github/skills/README.md`.
6. Remind me to reload the window and check `/skills`.

Never include data values or PII in the skill. Metadata and code patterns only.
