---
agent: catalog-builder
description: 'Add a semantic model to the knowledge base (metadata only)'
argument-hint: 'Model name and location'
---

Catalogue this semantic model into the knowledge base: ${input:model:e.g. 'Sales Model' in Fabric workspace 'Finance-Dev', or a PBIP folder path}

Environment: ${input:env:dev / test / prod}

Follow your workflow: ask what you need, collect metadata only, show me the proposed
`knowledge/models/<model>.md`, the catalog row, and suggested PII columns, then wait for my approval before writing.
