---
name: semantic-model-design
description: 'Power BI semantic model design standards: star schema, relationships, standard date table, storage modes, naming, hiding, RLS/OLS, AI-readiness. Use when designing, reviewing or changing model structure.'
---

# Semantic Model Design

## 1. Star schema
- **Facts** = events/transactions at a declared grain; narrow (keys + numeric columns).
- **Dimensions** = descriptive attributes; one row per entity; integer surrogate key.
- Avoid snowflakes (flatten dimensions upstream), fact-to-fact relationships, and wide "one big table" models.
- Multiple fact tables share **conformed dimensions** (same Date, Product, Customer).

## 2. Relationships
- One-to-many, single direction, dimension → fact.
- Bi-directional and many-to-many only with a documented reason; prefer `CROSSFILTER` / `TREATAS` in specific measures.
- Role-playing dates (order/ship/due): one active relationship to the standard date table; others inactive and used via `USERELATIONSHIP`.
- Keys: matching data types, no blanks/unmatched keys (check counts).

## 3. Date table
- Use the **standard date table** described in `knowledge/standards/date-table.md`. **Never create a new one.**
- It must be marked as a date table (or have calendars defined) and cover the full range of fact dates.
- Turn off Auto date/time (look for and remove `LocalDateTable_*` dependence, with approval).
- If a model is missing the standard date table, **ask the user** how they want to bring it in (shared dataflow, warehouse view, etc.).

## 4. Columns & storage
- Remove unused columns (biggest size/perf win). Hide keys and technical columns.
- Reduce cardinality: split datetime into date + time (if time is needed), round decimals, avoid GUID/free-text columns.
- Storage mode: Import by default; DirectQuery / Direct Lake / composite only with a reason; note it in the model's knowledge file.
- Incremental refresh for large facts (filters must fold).

## 5. Naming & organisation
- Tables: `Dim Customer` / `Fact Sales` or business names `[your standard]`. Columns: Title Case with spaces.
- Measures in a measures table or home tables `[your standard]`, organised with display folders.
- Every visible object has a description. This matters for Copilot and data agents.

## 6. Security & privacy
- RLS roles for row filtering; OLS to hide PII/sensitive columns from roles that don't need them.
- PII columns hidden by default and listed in `knowledge/pii-register.md`.
- Recommend removing PII from the model entirely if no report needs it.

## 7. AI-readiness (Copilot / data agents)
- Clear descriptions on tables, columns, measures.
- Business-friendly names; synonyms / linguistic schema where used.
- Hide helper/technical objects so AI doesn't pick them.
- Consistent base measures so AI reuses them instead of inventing logic.

## 8. Review checklist
Star schema ✔ · Single-direction 1:* relationships ✔ · Standard date table present & marked ✔ · No auto date/time ✔ ·
Unused columns removed ✔ · Keys hidden ✔ · Descriptions/format strings/folders ✔ · PII hidden & registered ✔ · RLS/OLS as required ✔
