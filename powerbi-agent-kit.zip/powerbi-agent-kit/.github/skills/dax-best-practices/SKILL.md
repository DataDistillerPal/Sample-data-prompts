---
name: dax-best-practices
description: 'DAX measure-writing standards and patterns: minimal-CALCULATE ladder, standard date table time intelligence, VAR/DIVIDE style, anti-patterns, validation queries. Use whenever writing, reviewing or fixing DAX.'
---

# DAX Best Practices

> Examples use `'Date'` and `[Total Sales]`. Always replace with the real names from
> `knowledge/standards/date-table.md` and the model's existing base measures.

## 1. Golden rules
1. **Correct → simple → fast**, in that order.
2. **Base measures first.** `Total Sales = SUM ( Sales[Sales Amount] )`. Everything else builds on base measures.
3. `VAR … RETURN` for anything more than one expression. Name variables clearly (`_CurrentSales`, `_PriorSales`).
4. `DIVIDE ( numerator, denominator )` — never `/`.
5. Columns fully qualified `'Table'[Column]`; measures never qualified `[Measure]`.
6. Every measure gets a description, format string and display folder.
7. **Never create a date table.** Use the standard one.

## 2. The "No-CALCULATE first" ladder
Work down this list and stop at the **first** pattern that gives the right result. Use `CALCULATE` only when you reach step 8.

| Step | Need | Pattern (no CALCULATE keyword) |
|---|---|---|
| 1 | Simple total / count | `SUM`, `COUNTROWS`, `DISTINCTCOUNT`, `AVERAGE`, `MIN`, `MAX` |
| 2 | Ratio / arithmetic | Combine base measures: `DIVIDE ( [Total Profit], [Total Sales] )` |
| 3 | A fixed business filter (e.g. exclude cancelled) | **Push upstream**: flag or pre-filtered column in SQL/Power Query, so the measure stays a plain `SUM` |
| 4 | Per-entity logic (per customer, per order) | Iterator over a **column**, referencing a measure: `SUMX ( VALUES ( Customer[Customer Key] ), [Total Sales] )` |
| 5 | Count entities meeting a condition | `COUNTROWS ( FILTER ( VALUES ( Customer[Customer Key] ), [Total Sales] > 1000 ) )` |
| 6 | Display / selection logic | `SELECTEDVALUE`, `HASONEVALUE`, `ISINSCOPE`, `SWITCH ( TRUE (), … )` |
| 7 | YTD / QTD / MTD | `TOTALYTD ( [Total Sales], 'Date'[Date] )` (or the model's calendar if calendar-based time intelligence is set up) |
| 7b | Running total / previous / moving average **in a visual only** | Suggest a **visual calculation** (`RUNNINGSUM`, `PREVIOUS`, `MOVINGAVERAGE`) instead of a model measure |
| 8 | Filter context must truly change | `CALCULATE`, see §3 |

**Honesty rule:** `CALCULATE` with a simple column predicate is often the *fastest* option. If a no-CALCULATE
version would be slower, harder to read, or give different results, use `CALCULATE` and say why.
Iterating a whole fact table with `FILTER` just to avoid `CALCULATE` is an anti-pattern.

Note: steps 4–5 still trigger context transition through the measure reference (an implicit CALCULATE). That's
fine and intended. The goal is readable code without unnecessary explicit CALCULATE, not a ban on the concept.

## 3. When CALCULATE is genuinely needed
Add a comment: `-- CALCULATE needed: <reason>`

| Scenario | Example |
|---|---|
| Shift time (prior year, prior month, parallel period) | `CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( 'Date'[Date] ) )` |
| Remove filters (% of total) | `DIVIDE ( [Total Sales], CALCULATE ( [Total Sales], REMOVEFILTERS ( Product ) ) )` |
| Activate an inactive relationship | `CALCULATE ( [Total Sales], USERELATIONSHIP ( Sales[Ship Date], 'Date'[Date] ) )` |
| Virtual relationship | `CALCULATE ( [Total Budget], TREATAS ( VALUES ( Product[Category] ), Budget[Category] ) )` |
| Intersect, not overwrite, a filter | `CALCULATE ( [Total Sales], KEEPFILTERS ( Product[Color] = "Red" ) )` |
| Simple filter that can't be pushed upstream | `CALCULATE ( [Total Sales], Product[Color] = "Red" )`, using a **column predicate**, never `FILTER ( Product, … )` |

## 4. Time intelligence with the standard date table
- Always reference the standard date table's **date column** from `knowledge/standards/date-table.md`.
- Use its existing attribute columns (Year, Month, Fiscal Year, Is Current Month, …). Never recreate them in DAX.
- If the model defines calendars (calendar-based time intelligence), pass the calendar to time-intelligence functions
  instead of the date column. Check before assuming.
- Fiscal year: use the date table's fiscal columns, or the year-end argument (`TOTALYTD ( [Total Sales], 'Date'[Date], "6/30" )`).
  Confirm the fiscal year end with the user.
- Inactive date relationships (ship date, due date) → `USERELATIONSHIP`, not a second date table.

### Standard pattern set (adapt names)
```dax
Total Sales = SUM ( Sales[Sales Amount] )

Sales YTD = TOTALYTD ( [Total Sales], 'Date'[Date] )

Sales PY =
-- CALCULATE needed: shift the date filter back one year
CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( 'Date'[Date] ) )

Sales YoY =
VAR _Current = [Total Sales]
VAR _Prior   = [Sales PY]
RETURN
    IF ( NOT ISBLANK ( _Current ) && NOT ISBLANK ( _Prior ), _Current - _Prior )

Sales YoY % = DIVIDE ( [Sales YoY], [Sales PY] )

Avg Sales per Customer =
AVERAGEX ( VALUES ( Customer[Customer Key] ), [Total Sales] )

Customers Over 1K =
COUNTROWS ( FILTER ( VALUES ( Customer[Customer Key] ), [Total Sales] > 1000 ) )
```

## 5. Anti-patterns to flag and fix
| Anti-pattern | Fix |
|---|---|
| `CALCULATE ( SUM ( … ) )` with no filters | Plain `SUM`, or reference the base measure |
| `CALCULATE ( [M], FILTER ( 'Table', 'Table'[Col] = x ) )` | Column predicate `'Table'[Col] = x`, or push upstream |
| Nested `CALCULATE` inside `CALCULATE` | Flatten into one call |
| `IFERROR` / `ISERROR` | `DIVIDE`, explicit `ISBLANK` checks |
| `/` division | `DIVIDE` |
| Same aggregation repeated in many measures | One base measure, referenced |
| `SUMX ( FactTable, … )` with `RELATED` on large facts | Pre-compute the column upstream, or iterate a smaller table |
| Measures returning 0 instead of BLANK (`+ 0`) | Keep BLANK, which keeps visuals clean and fast |
| Calculated columns for row logic | Move to SQL / Power Query |
| `CALENDAR()` / `CALENDARAUTO()` tables | Remove; use the standard date table |
| Bi-directional relationships used to make a measure work | Use `CROSSFILTER` / `TREATAS` inside the measure |
| Repeated logic across 10+ measures | Consider a DAX UDF (if compatibility level allows; ask first) |

## 6. Validation query template
```dax
EVALUATE
TOPN (
    20,
    SUMMARIZECOLUMNS (
        'Date'[Year],
        Product[Category],
        "Current", [Total Sales],
        "New", [<New Measure>]
    ),
    'Date'[Year], DESC
)
```
Never include PII columns in validation queries (see data policy).
