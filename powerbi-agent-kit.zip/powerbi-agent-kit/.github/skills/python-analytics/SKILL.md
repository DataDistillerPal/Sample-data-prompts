---
name: python-analytics
description: 'Python standards for data extraction, profiling and analysis: pandas/polars style, semantic-link for Power BI models in Fabric, reproducible scripts, statistics, privacy-safe outputs. Use whenever writing or running Python for data work.'
---

# Python for Analytics Engineering

## 1. Golden rules
1. **Show before you run.** Before executing any script that reads data, show it and state what it reads. Wait for approval.
2. **Read only what you need:** select columns in the query (SQL/DAX), not after loading everything.
3. **No PII in outputs** unless `APPROVE PII`; mask when approved. Never print whole DataFrames: use `.head(20)`, `.describe()`, counts.
4. **No data written to the repo** (CSV, parquet, pickle, notebook outputs) unless approved. Clear notebook outputs before saving.
5. **No secrets in code.** Use environment variables, `azure-identity` (`DefaultAzureCredential`), or Key Vault.
6. **Reproducible:** pin package versions in `requirements.txt`; set random seeds; functions over copy-pasted cells.
7. **Never generate a date dimension.** Pull the standard date table from the model or warehouse.

## 2. Getting data
| Source | Approach |
|---|---|
| Power BI / Fabric semantic model (in a Fabric notebook) | `semantic-link` (`import sempy.fabric as fabric`): `fabric.evaluate_measure(...)` or `fabric.evaluate_dax(...)` so you reuse the model's measures instead of re-implementing logic |
| SQL Server / Azure SQL / Fabric Warehouse | `pyodbc` or `sqlalchemy` + parameterized queries → `pd.read_sql` |
| Lakehouse (Fabric notebook) | `spark.read.table(...)` / `spark.sql(...)`, then `.toPandas()` only on small, aggregated results |
| Files | `pd.read_csv` / `pd.read_excel` / `pl.read_parquet` with explicit `usecols` and `dtype` |

```python
import pandas as pd
from sqlalchemy import create_engine, text

engine = create_engine(CONNECTION_URL)  # from environment / Key Vault, never hard-coded

query = text("""
    SELECT OrderDate, ProductKey, SalesAmount
    FROM rpt.vw_FactSales
    WHERE OrderDate >= :start AND OrderDate < :end
""")
df = pd.read_sql(query, engine, params={"start": "2026-01-01", "end": "2026-07-01"})
```

## 3. Style
- Type hints and docstrings on functions; `snake_case` names; small single-purpose functions.
- Method chaining for pandas transforms; avoid row loops (`iterrows`): vectorize.
- Explicit dtypes (`category` for low-cardinality text, nullable `Int64`, `datetime64`).
- Prefer **polars** for large local data when available; pandas otherwise.
- Validate with `assert` checks on row counts, nulls in keys, and uniqueness.

## 4. Analysis toolkit
| Task | Tools |
|---|---|
| Profiling / data quality | `df.describe()`, null %, duplicates on keys, value ranges (non-PII columns) |
| Trends & variance | groupby + pct_change, rolling windows |
| Statistics | `scipy.stats` (t-test, chi-square), effect size, confidence intervals. State assumptions |
| Forecasting | `statsmodels` (ETS/SARIMAX), `prophet` if available. Always show backtest error |
| ML | `scikit-learn` pipelines, train/test split, cross-validation; report metrics honestly |
| Charts | `matplotlib` / `plotly`; label axes and units; no PII in labels |

## 5. Communicating results
- Headline first ("Sales fell 8% QoQ, driven by Region X").
- Then supporting numbers, method, caveats (sample size, missing data, assumptions).
- Suggest whether the result should become a **DAX measure** in the model (so reports stay consistent) rather than living only in Python.
