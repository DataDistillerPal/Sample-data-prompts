# Skills Library: how to add a skill

Skills are reusable expertise the agents load **automatically** when your request matches the skill's
`description`. This folder is meant to grow: add a skill whenever you catch yourself correcting the agent
the same way twice, or when you have a team standard worth encoding.

## Current skills
| Skill | Use for |
|---|---|
| `dax-best-practices` | DAX measures, minimal-CALCULATE ladder, time intelligence with the standard date table |
| `power-query-best-practices` | M, folding, staging pattern, incremental refresh |
| `sql-best-practices` | T-SQL extraction and analysis, views for Power BI |
| `python-analytics` | pandas/polars, semantic-link, statistics, forecasting |
| `semantic-model-design` | Star schema, relationships, security, AI-readiness |

*(Add a row here each time you add a skill.)*

## Add a skill: the easy way
In Copilot Chat type **`/add-skill`** and describe what you want, e.g.
> /add-skill Our standard for currency conversion measures using the FX Rate table

The agent drafts the skill, shows it to you, and saves it after you approve.

## Add a skill: manually
1. Create a folder: `.github/skills/<skill-name>/` (lowercase-with-hyphens).
2. Create `SKILL.md` inside it using the template below. The folder name must match `name:`.
3. (Optional) add `references/` (longer docs, examples) or `scripts/` (Python/SQL snippets) and mention them in SKILL.md.
4. Reload VS Code (`Ctrl+Shift+P` → *Developer: Reload Window*). Type `/skills` in chat to confirm it's listed.

## Template
```markdown
---
name: my-skill-name
description: 'One or two sentences: WHAT this skill covers and WHEN to use it. Include trigger words the user would type.'
---

# My Skill Name

## Golden rules
1. …
2. …

## Patterns
<code examples with the right language tag>

## Anti-patterns
| Don't | Do instead |
|---|---|

## Validation
How to check the output is correct.
```

## Tips for good skills
- **The description is everything.** It decides when the skill loads. Be specific ("FX conversion measures using 'FX Rate' table"), not vague ("finance stuff").
- Keep SKILL.md focused (under ~300 lines); move long material into `references/`.
- Show real examples from your models (metadata and code only, **never data values or PII**).
- One topic per skill. Split big ones.

## Skill ideas backlog
- [ ] Currency conversion pattern
- [ ] RLS patterns for our clients
- [ ] Paginated report (RDL) standards
- [ ] Fabric Lakehouse / notebook conventions
- [ ] Client-specific KPI definitions
- [ ] Incremental refresh & partitioning
