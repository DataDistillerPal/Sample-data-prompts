---
name: sql-best-practices
description: 'T-SQL standards for data extraction and analysis: readable style, sargable filters, CTEs, window functions, set-based logic, views for Power BI, performance and privacy. Use whenever writing or reviewing SQL.'
---

# SQL (T-SQL) Best Practices

Default dialect: T-SQL (SQL Server, Azure SQL, Fabric Warehouse / SQL analytics endpoint). Ask if another dialect applies.

## 1. Golden rules
1. **Never `SELECT *`.** List columns explicitly. Exclude PII unless approved.
2. **Set-based, not row-by-row.** No cursors or loops for data transformation.
3. **Sargable filters:** keep columns bare on the left of a predicate.
   - ❌ `WHERE YEAR(OrderDate) = 2026`
   - ✅ `WHERE OrderDate >= '2026-01-01' AND OrderDate < '2027-01-01'`
4. **Explicit joins** (`INNER JOIN … ON`), never comma joins. Watch for join fan-out: confirm the grain after joining.
5. **CTEs for readability**, one logical step per CTE.
6. **Limit exploratory output:** `TOP (20)` for any row-level look; aggregates preferred.
7. **Parameters, not string concatenation**, for any dynamic SQL (prevents SQL injection).
8. **Never create date tables in SQL for Power BI.** The standard date table already exists.

## 2. Style
```sql
WITH OrderLines AS (
    SELECT
        s.SalesOrderKey,
        s.OrderDate,
        s.CustomerKey,
        s.ProductKey,
        s.Quantity,
        s.SalesAmount
    FROM dbo.FactSales AS s
    WHERE s.OrderDate >= @StartDate
      AND s.OrderDate <  @EndDate
      AND s.IsCancelled = 0
),
CustomerTotals AS (
    SELECT
        ol.CustomerKey,
        SUM(ol.SalesAmount)              AS TotalSales,
        COUNT(DISTINCT ol.SalesOrderKey) AS OrderCount
    FROM OrderLines AS ol
    GROUP BY ol.CustomerKey
)
SELECT
    ct.CustomerKey,
    ct.TotalSales,
    ct.OrderCount,
    RANK() OVER (ORDER BY ct.TotalSales DESC) AS SalesRank
FROM CustomerTotals AS ct;
```
- Keywords UPPERCASE; one column per line; meaningful aliases; schema-qualify objects (`dbo.`).
- End statements with `;`. Comment the *why*, not the *what*.

## 3. Useful patterns
| Need | Pattern |
|---|---|
| Latest row per key (dedupe) | `ROW_NUMBER() OVER (PARTITION BY Key ORDER BY ModifiedDate DESC) = 1` |
| Running total | `SUM(x) OVER (PARTITION BY … ORDER BY … ROWS UNBOUNDED PRECEDING)` |
| Prior period value | `LAG(x) OVER (PARTITION BY … ORDER BY …)` |
| Existence check | `EXISTS` / `NOT EXISTS` instead of `IN` with large subqueries or `LEFT JOIN … IS NULL` (both fine; be consistent) |
| Conditional aggregation | `SUM(CASE WHEN … THEN x ELSE 0 END)` |
| Safe division | `x / NULLIF(y, 0)` |
| Data profiling | `COUNT(*)`, `COUNT(col)`, `COUNT(DISTINCT col)`, `MIN/MAX`. **Not** on PII without approval |

## 4. SQL for Power BI
- Expose **views** (`rpt.vw_FactSales`, `rpt.vw_DimCustomer`) shaped to the star schema: surrogate keys, business-friendly names, correct types.
- Push heavy joins, deduplication and business filters into views so Power Query stays simple and folds.
- Keep fact views narrow (keys + numeric measures). Put descriptive attributes in dimension views.
- Avoid `ORDER BY` in views. Avoid scalar UDFs in large queries (performance).
- Keep `NOLOCK` out of production logic unless the user explicitly accepts dirty reads.

## 5. Performance checks
- Look at the execution plan for scans on large tables with selective filters → suggest indexes (don't create them without approval).
- Prefer `UNION ALL` over `UNION` when duplicates are impossible.
- Avoid functions on join/filter columns; avoid implicit conversions (match data types).
- Temp tables for large multi-step transformations; table variables only for small sets.

## 6. Privacy
- Exclude PII columns by default; when approved, aggregate or mask: `LEFT(Email, 1) + '***@' + SUBSTRING(Email, CHARINDEX('@', Email) + 1, 100)`.
- Never write query results to files in the repo without approval.
