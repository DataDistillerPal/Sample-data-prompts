---
name: power-query-best-practices
description: 'Power Query (M) standards: query folding, staging/reference pattern, parameters, typing, error handling, incremental refresh, performance anti-patterns. Use whenever writing or reviewing Power Query / Dataflows.'
---

# Power Query (M) Best Practices

## 1. Golden rules
1. **Keep it folding.** Do filtering, column removal, joins, and grouping in steps that fold to the source.
   Check with *right-click step → View Native Query*. When folding breaks, move that logic to SQL or later in the query.
2. **Filter rows and remove columns as early as possible.** Use `Table.SelectColumns` (an explicit keep-list), not `Table.RemoveColumns`.
3. **Set data types once, explicitly**, near the end, with `Table.TransformColumnTypes`. Remove auto "Changed Type" steps that hard-code every column.
4. **Name steps meaningfully** (`Filtered Active Customers`, not `Filtered Rows1`).
5. **Never create a date table in Power Query.** Use the standard date table.
6. **No credentials in M.** Use parameters and the data source credential manager.

## 2. Structure: staging → transform → load
```
Parameters      ServerName, DatabaseName, RangeStart, RangeEnd
Staging (not loaded)   stg_Sales  = source + folding filters + SelectColumns
Transform (loaded)     Sales      = reference stg_Sales + business shaping + types
Functions              fn_CleanText, fn_...
```
- Disable load on staging queries.
- Prefer **SQL views** for heavy joins. Power Query should mostly select, rename and type.

## 3. Patterns
```powerquery
let
    Source = Sql.Database ( ServerName, DatabaseName ),
    SalesTable = Source{[Schema = "dbo", Item = "FactSales"]}[Data],
    // Fold: filter + column selection run at the source
    FilteredRows = Table.SelectRows ( SalesTable, each [OrderDate] >= RangeStart and [OrderDate] < RangeEnd ),
    SelectedColumns = Table.SelectColumns (
        FilteredRows,
        { "SalesOrderKey", "OrderDateKey", "CustomerKey", "ProductKey", "Quantity", "SalesAmount" }
    ),
    Typed = Table.TransformColumnTypes (
        SelectedColumns,
        {
            { "Quantity", Int64.Type },
            { "SalesAmount", Currency.Type }
        }
    )
in
    Typed
```
- **Incremental refresh:** `RangeStart` / `RangeEnd` filters must fold; use `>=` start and `<` end.
- **Native SQL** (`Value.NativeQuery`): only when needed; add `[EnableFolding = true]` where supported.
- **Merges:** merge on keys with matching types; expand only needed columns; prefer doing the join in SQL.
- **Error handling:** `try … otherwise` for expected bad values; never silently `Table.RemoveRowsWithErrors` without telling the user how many rows were dropped.
- **Text cleaning:** `Text.Trim`, `Text.Clean`, consistent casing on join keys.
- **Custom functions** for repeated logic; document parameters.

## 4. Anti-patterns
| Anti-pattern | Fix |
|---|---|
| Auto "Changed Type" on every column right after Source | One explicit typing step at the end |
| `Table.Buffer` everywhere | Only when you've proved it helps (e.g. a small lookup used repeatedly) |
| Adding index / custom columns before filters (breaks folding) | Filter first, add columns later |
| Hard-coded file paths / server names | Parameters |
| Loading staging queries | Disable load |
| Pivot/unpivot on huge non-folding sources | Do it in SQL |
| Many queries pulling the same source separately | One staging query, referenced |
| Row-level business logic duplicated in DAX calculated columns | Keep it here or in SQL, not both |

## 5. Validation checklist
- Row count before/after each major step (counts only, never PII values).
- Column list and types as expected.
- Query still folds (View Native Query available on the last folding step).
- Refresh time noted if the user cares about performance.
