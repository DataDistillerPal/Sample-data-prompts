# Copilot Instructions — Power BI Analytics Engineering Workspace

These rules apply to **every** Copilot chat, agent, and skill in this workspace.
Edit the `[bracketed]` values to match your standards.

---

## 1. Read these first (every session)

Before doing any work, load the context that applies:

| File | When |
|---|---|
| `.github/instructions/data-policy.instructions.md` | **Always.** Data boundaries — non-negotiable. |
| `knowledge/model-catalog.md` | Any question about which models exist or where data lives. |
| `knowledge/models/<model>.md` | Before working on a specific model. |
| `knowledge/standards/date-table.md` | Any date, time-intelligence, or calendar question. |
| `knowledge/pii-register.md` | Before querying any table that could contain people data. |
| `knowledge/learned-rules.md` | Always — these are corrections the user has made before. |
| `.github/skills/*` | Load the matching skill for DAX, Power Query, SQL, Python, or model design work. |

If a knowledge file is missing or out of date, say so and offer to run the **catalog-builder** agent.

---

## 2. Ask before assuming (core behaviour)

Never silently fill a gap. Before building or changing anything, check for these unknowns and
**ask** about any that matter (group them, max 5 questions at a time, numbered so the user can answer quickly):

1. **Which model / workspace / environment** (dev, test, prod)?
2. **Business definition** — e.g. does "Sales" include tax, returns, cancelled orders?
3. **Grain** — per order, per line, per customer, per day?
4. **Which date** — order date, ship date, invoice date? Calendar or fiscal year?
5. **Filters & scope** — which regions, products, periods are in or out?
6. **Expected result** — a known number to validate against?
7. **Output** — measure, query, Power Query step, notebook, report spec, or explanation?

Rules:
- If the user says "just go" or "use your judgement", proceed — but **list every assumption explicitly** at the top of your answer under **Assumptions**.
- If two reasonable interpretations give different numbers, **always ask** — never pick one silently.
- If you discover mid-task that an earlier assumption was wrong, stop and tell the user.

---

## 3. Safety rules

- **Never change a model, query, or file without explicit approval.** Propose → wait for "yes" → apply.
- **Never delete** tables, columns, measures, relationships, queries, or roles unless the user names the exact object and confirms.
- **Dev/test only.** If the target looks like production (`PROD`, `Production`, `Live`, `[your prod workspace names]`), stop and ask.
- **One logical change at a time**, each validated (see §5).
- Never rename measures or columns without approval — renames break reports.
- Never change RLS / OLS roles unless explicitly asked.

---

## 4. Environment facts  *(fill these in)*

- Primary platform: Power BI / Microsoft Fabric. Sources: `[SQL Server / Azure SQL / Fabric Lakehouse / Warehouse / SharePoint / Excel …]`
- SQL dialect: **T-SQL** unless stated otherwise.
- Standard **date table** exists in most models — see `knowledge/standards/date-table.md`.
  **Do not create a calendar/date table.** Reference the standard one. If a model lacks it, ask the user.
- Python environment: `[local venv / Fabric notebooks with semantic-link]`.

---

## 5. Validation (always)

- New or changed DAX measure → run a DAX query showing results by 1–2 dimensions, before vs after.
- New or changed SQL → show row count and a small aggregate check, never raw PII rows (see policy).
- New or changed Power Query → confirm row count, column list, data types, and whether the step still folds.
- If numbers change unexpectedly → roll back and report.

---

## 6. Output format

**Findings:**

| Severity | Area | Object | Issue | Recommended fix |
|---|---|---|---|---|

High = wrong numbers, performance killers, security/privacy risks · Medium = maintainability · Low = naming/cosmetic

**Code:** always in fenced blocks with the language (`dax`, `powerquery`, `sql`, `python`), followed by a 1–3 bullet "why".

**End every substantial answer with:** Assumptions (if any) · Next steps (max 5).

---

## 7. Learning loop

When the user corrects you ("no, we always …", "that's wrong because …"):
1. Apply the correction.
2. Offer to save it: *"Should I add this to `knowledge/learned-rules.md`?"*
3. Only write it after the user says yes. Never store data values, names, or PII in knowledge files.
